package principal;

import java.util.Scanner;

import entites.Conta;
import entites.ContaCorrente;
import entites.ContaPoupanca;

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		
		String nome = " Pablo";
		int contaNumero = 2323;
		int agencia = 4545;
		
		Conta conta = new Conta (nome, contaNumero, agencia);
		
		ContaCorrente cc = new ContaCorrente(nome, contaNumero, agencia);
		
		ContaPoupanca cp = new ContaPoupanca(nome, contaNumero, agencia);
		
	
			
		cc.depositar(50.00);
		cc.sacar(50.00);
		System.out.println(cc);
		System.out.println("/*******************/");
		
		
		cp.depositar(250.00);
		cp.sacar(50.00);
		System.out.println(cp);
		System.out.println("/*******************/");
		
		sc.close();
	}
}
