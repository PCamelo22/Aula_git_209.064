package entites;

public class Conta {
	
	private String titular;
	private int numeroConta;
	private int Agencia;
	protected double saldo;
	
	public Conta() {
		super();
	}
	
	
	public Conta(String titular, int numeroConta, int Agencia) {
		super();
		this.titular = titular;
		this.numeroConta = numeroConta;
		this.Agencia = Agencia;
	}
	public void setTitular(String titular) {
		this.titular = titular;
	}
	public int getNumeroConta() {
		return numeroConta;
	}
	public void setNumeroConta(int numeroConta) {
		this.numeroConta = numeroConta;
	}
	public int getAgencia() {
		return Agencia;
	}
	public void setAgencia(int agencia) {
		this.Agencia = agencia;
	}
	public double getSaldo() {
		return saldo;
	} 
	public void depositar (double valor) {
		saldo += valor ;
	}
	public void sacar (double valor) {
		saldo -= valor;
	}
	public String toString () {
		// TODO Auto-generated method stub
		return "numero da conta: " + numeroConta + "\nAgencia: " + Agencia +
				"\ntitular" + titular + " saldo: " + saldo;
	}
	
}
