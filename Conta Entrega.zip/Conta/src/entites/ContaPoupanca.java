package entites;

public class ContaPoupanca extends Conta{

	public ContaPoupanca() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ContaPoupanca(String titular, int numeroConta, int Agencia) {
		super(titular, numeroConta, Agencia);
		// TODO Auto-generated constructor stub
	}
	@Override
	public void sacar(double valor) {
		saldo -= valor +5;
		
	}
	

}
