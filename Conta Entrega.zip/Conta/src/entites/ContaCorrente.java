package entites;

public class ContaCorrente extends Conta{

	public ContaCorrente() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ContaCorrente(String titular, int numeroConta, int Agencia) {
		super(titular, numeroConta, Agencia);
		// TODO Auto-generated constructor stub
	}
 @Override
 public void sacar(double valor) {
		if (saldo - (valor - 5) <= -150) {
	        saldo -= valor + 5;
	    } else {
	        System.out.println("voce nao possui mais limete no cheque especial. (R$150.00)");
	    
	    }
 }
}
	
	

